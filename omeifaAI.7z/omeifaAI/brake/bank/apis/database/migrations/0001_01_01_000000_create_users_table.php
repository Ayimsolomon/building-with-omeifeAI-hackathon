<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{

   public function up()
{
    Schema::create('users', function (Blueprint $table) {
        $table->id(); // This creates a BIGINT UNSIGNED AUTO_INCREMENT primary key
        $table->string('email');
        $table->string('first_name');
        $table->string('last_name');
        $table->string('phone_number');
        $table->string('password');
        $table->string('token')->nullable();
        $table->string('image_url')->nullable();
        $table->timestamp('email_verified_at')->nullable();
        $table->string('remember_token', 100)->nullable();
        $table->timestamps();
        $table->bigInteger('user_id')->unsigned(); // Adding user_id column
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
