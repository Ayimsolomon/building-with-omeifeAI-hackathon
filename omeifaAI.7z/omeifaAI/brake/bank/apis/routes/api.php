<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Omeife;

Route::get('/omeife_userdetails/{id}', [Omeife::class, 'getUserDetails']);
Route::post('/omeife-login', [Omeife::class, 'login']);
Route::post('/omeife-register', [Omeife::class, 'omeife']);
Route::post('/omeife-knowledge/{id}', [Omeife::class, 'knowledge']); // Define the API route for the knowledge function
Route::get('/translated-text/{id}', [Omeife::class, 'getTranslatedText']);
