<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Model;



class Users extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

   protected $fillable = [
        'email',
        'first_name',
        'last_name',
        'phone_number',
        'password',
        'token',
        'image_url',
        'email_verified_at',
        'remember_token',
        'user_id',
    ];

    // Example relationship (if needed)
    public function anotherTable()
    {
        return $this->hasMany(AnotherModel::class, 'user_id');
    }
    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'string',
    ];
}