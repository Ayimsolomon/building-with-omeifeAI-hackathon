<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
//use App\Models\profilePicture;
use App\Models\UserRegistration;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{     
    
   public function omeife(Request $request)
    {
        $request->validate([
            'email' => 'required|email|max:100',
            'first_name' => 'required|string|max:20',
            'last_name' => 'required|string|max:20',
            'phone_number' =>'required|string|max:11',
            'password' => 'required|confirmed|min:8',
            'password_confirmation' => 'required|confirmed|min:8',
        ]);

        $apiKey = vMmJEfsBrmkuF6ML7GUN7K19zMgWeb5bbtPt7T5eOOMtu1DGwe; // Retrieve API key from .env file.
        if (!$apiKey) {
            return response()->json([
                'status' => 'error',
                'message' => 'API key not configured.',
            ], 500);
        }

        $headers = [
            'Authorization' => 'Bearer ' . $apiKey,
            'Accept' => 'application/json', // Important for JSON responses
        ];

        $response = Http::withHeaders($headers)->post('https://apis.omeife.ai/api/v1/user/register');

    }
    
    
    
     public function getUserDetails($id)
{
    $user = UserRegistration::find($id);

    if (!$user) {
        return response()->json(['error' => 'User not found'], 404, ['Content-Type' => 'application/json']);
    }

    $accountDetails = $user->accountDetail;

    return response()->json([
        'message' => 'User details fetched successfully',
        'user' => [
            'first_name' => $user->first_name,
            'surname' => $user->surname,
            'email' => $user->email,
            'username' => $user->username,
            'mobile_number' => $user->mobile_number,
            'nin' => $user->nin,
            'address' => $user->address,
            'country' => $user->country,
            'state' => $user->state,
            'city' => $user->city,
            'profilePicture' => $user->profilePicture,
            'account_name' => $accountDetails->account_name,
            'account_number' => $accountDetails->account_number,
            'bank_name' => $accountDetails->bank_name,
            'balance' => $accountDetails->balance
        ]
    ], 200, ['Content-Type' => 'application/json']);
}

   
//fetching user details using account_number
   public function checkAccount($accountNumber)
    {
  $validator = Validator::make(['account_number' => $accountNumber], [
        'account_number' => 'required|string|size:10',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'message' => 'Invalid account number format',
            'errors' => $validator->errors()
        ], 422);
    }

    $user = UserRegistration::where($accountNumber);

    if (!$user) {
        return response()->json(['error' => 'User not found'], 404);
    }

  $accountNumber = $user->userDetail;

    return response()->json([
        'message' => 'User details fetched successfully',
        'user' => [
            'account_name' => $accountDetails ? $accountDetails->account_name : 'N/A',
            'account_number' => $accountDetails ? $accountDetails->account_number : 'N/A',
            'bank_name' => $accountDetails ? $accountDetails->bank_name : 'N/A',
        ],
    ], 200);
}


//uploading user profile picture
public function upload(Request $request, $id)
{
    try {
        \Log::info('Upload method called');
        \Log::info('Request data:', $request->all());
        \Log::info('Has file: ' . ($request->hasFile('profilePicture') ? 'Yes' : 'No'));

        // Validate the request with explicit error messages
        $validator = \Validator::make($request->all(), [
            'profilePicture' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($validator->fails()) {
            \Log::warning('Validation failed', $validator->errors()->toArray());

            return response()->json([
                'error' => 'Image must be a valid JPG, PNG, or GIF and must not exceed 2MB.',
                'details' => $validator->errors()
            ], 422); // Unprocessable Entity
        }

        \Log::info('Validation passed');

        // Retrieve user
        $userRegistration = UserRegistration::find($id);
        if (!$userRegistration) {
            return response()->json(['error' => 'User not found.'], 404);
        }

        // Check if the same user has already uploaded an image
        if (!empty($userRegistration->profilePicture)) {
            return response()->json([
                'error' => 'You can only upload a profile picture once.',
                'existing_image' => $userRegistration->profilePicture
            ], 409); // Conflict status code
        }

        // Process the image
        $file = $request->file('profilePicture');
        $originalName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
        $extension = $file->extension();
        $imageName = $originalName . '.' . $extension; // Ensure unique filename

        // Move the uploaded image to the public/images directory
        $file->move(public_path('images'), $imageName);

        // Generate the full URL
        $imageUrl = asset('images/' . $imageName);

        // Update the user's profile picture
        $userRegistration->profilePicture = $imageUrl;
        $userRegistration->save();

        return response()->json([
            'success' => 'Profile picture uploaded successfully.',
            'image' => $imageUrl // Return full image URL
        ]);
    } catch (\Exception $e) {
        \Log::error('Error: ' . $e->getMessage());
        return response()->json(['error' => 'Something went wrong. ' . $e->getMessage()], 500);
    }
}

}