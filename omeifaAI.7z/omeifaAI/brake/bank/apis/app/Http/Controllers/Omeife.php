<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Event;
use App\Models\Users;
use App\Models\Querys; // Import the Querys model
use Illuminate\Support\Facades\Hash; // Add this line
use App\Models\Translation; // Assuming you have a Translation model
use Illuminate\Support\Facades\Auth;
use Laravel\Sanctum\PersonalAccessToken;


class Omeife extends Controller
{
    public function omeife(Request $request)
    {
        $validatedData = $request->validate([
            'email' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'phone_number' => 'required',
            'password' => 'required|confirmed|min:8',
            'password_confirmation' => 'required|min:8',
        ]);

        $apiKey = env('OMEIFE_API_KEY'); // Retrieve API key from .env file.

        if (!$apiKey) {
            return response()->json([
                'status' => 'error',
                'message' => 'API key not configured.',
            ], 500);
        }

        try {
            $response = Http::withHeaders([
                "Authorization" => "Bearer " . $apiKey, // Removed single quotes around Bearer
                "Content-Type" => "application/json",
            ])->post('https://apis.omeife.ai/api/v1/user/register', $validatedData);

            if ($response->successful()) {
               $responseData = $response->json();

            if (isset($responseData['data'])) {
                $userData = $responseData['data']['user'];
                $token = $responseData['data']['token'];

                $user = Users::create([ // Changed to User model
                    'id' => $userData['id'],
                    'email' => $userData['email'],
                    'first_name' => $userData['first_name'],
                    'last_name' => $userData['last_name'],
                    'phone_number' => $userData['phone_number'],
                    'password' => Hash::make($request->password),
                    'token' => $token,
                    'image_url' => $userData['imageUrl'],
                ]);

                event(new Registered($user)); // Fire the registered event


                return response()->json([
                    'status' => 'success',
                    'message' => 'Account created successfully.',
                    'data' => $user, // Changed to $user
                ]);
               
                }else{
                     return response()->json([
                        'status' => 'error',
                        'message' => 'Data not found in the API response.',
                        'api_response' => $responseData, // return the entire response, to help debug.
                    ], 400);
                }
            } else {
                Log::error('Omeife API Error: ' . $response->status() . ' - ' . $response->body()); //Log the API error.
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed to create account. API returned an error.',
                    'api_response' => $response->json(), // Return the API response for debugging
                ], $response->status()); // Use the API's status code
            }
        } catch (\Exception $e) {
            Log::error('Omeife API Exception: ' . $e->getMessage()); //Log any exceptions.
            return response()->json([
                'status' => 'error',
                'message' => 'An error occurred while processing your request.',
            ], 500);
        }
    }
    
    
     public function getUserDetails($id)
{
    $user = Users::find($id);

    if (!$user) {
        return response()->json(['error' => 'User not found'], 404, ['Content-Type' => 'application/json']);
    }

    $accountDetails = $user->accountDetail;

    return response()->json([
        'message' => 'User details fetched successfully',
        'user' => [
            'first_name' => $user->first_name,
            'email' => $user->email,
            'phone_number' => $user->phone_number,
            'image_url' => $user->image_url,
        
        ]
    ], 200, ['Content-Type' => 'application/json']);
}

   
    
    //request for knowledge 


 public function knowledge(Request $request, $id)
    {
        $validatedData = $request->validate([
            'text' => 'required',
            'from' => 'required',
            'to' => 'required', // Add user_id validation
        ]);

        $apiKey = env('OMEIFE_API_KEY');

        if (!$apiKey) {
            return response()->json([
                'status' => 'error',
                'message' => 'API key not configured.',
            ], 500);
        }

        $response = Http::withHeaders([
            "Authorization" => "Bearer " . $apiKey,
            "Content-Type" => "application/json",
        ])->post('https://apis.omeife.ai/api/v1/user/developer/translate', $validatedData);

        Log::info('Omeife API Response:', $response->json());

        if ($response->successful()) {
            $responseData = $response->json();

            // Save to database, including user_id
            Translation::create([
                'original_text' => $validatedData['text'],
                'translated_text' => $responseData['data']['translated_text'],
                'from_language' => $validatedData['from'],
                'to_language' => $validatedData['to'],
                'api_response' => json_encode($responseData),
                'id' => $id, // Save user_id
            ]);

            return response()->json($responseData);
        } else {
            return response()->json([
                'status' => 'error',
                'message' => 'Translation failed.',
                'error' => $response->json(), // Include the error response for debugging
            ], $response->status());
        }
    }
    
     public function login(Request $request)
    {
        Log::info('Login attempt:',$request->all()); // Log the incoming request

        // Validate request input
        $request->validate([
            'email' => 'required|regex:/^\S*$/', // No spaces allowed
            'password' => 'required|string|min:8',
        ]);

        // Find user by username (case-insensitive)
        $user = Users::whereRaw('LOWER(email) = ?', [strtolower($request->input('email'))])->first();

        // Check if user exists and password is correct
        if (!$user || !Hash::check($request->input('password'), $user->password)) {
            Log::warning('Login failed: Invalid username or password. Username: ' . $request->input('username')); // Log failed login attempt
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid username or password'
            ], 401);
        }

        // Revoke old tokens and generate a new one
        $user->tokens()->delete();
        $token = $user->createToken('auth_token')->plainTextToken;

      //  Log::info('Login successful. Username: ' . $user->username); // Log successful login

        // Return success response
        return response()->json([
            'status' => 'success',
            'message' => 'Login successful',
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'email' => $user->email,
            ]
        ], 200);
    }
    
    
public function getTranslatedText($id)
{
    try {
        $translation = Translation::where('id', $id)->firstOrFail(); // Use firstOrFail()

        return response()->json([
            'translated_text' => $translation->translated_text,
        ]);
    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        return response()->json([
            'status' => 'error',
            'message' => 'Translation not found.',
        ], 404);
    } catch (\Exception $e) {
        Log::error('Error fetching translated text: ' . $e->getMessage());
        return response()->json([
            'status' => 'error',
            'message' => 'An error occurred.',
        ], 500);
    }
}
    }